#ifndef GAME_DATA_H
#define GAME_DATA_H

//�w�b�_�[
#include "screen.h"

//define

//struct
struct GameData
{
	SCREEN		now_screen;
	SCREEN		old_screen;
};
#endif